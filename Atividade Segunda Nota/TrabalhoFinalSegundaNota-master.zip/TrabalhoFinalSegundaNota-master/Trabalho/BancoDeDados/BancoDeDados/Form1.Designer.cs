﻿
namespace WinFormsAppBancoExemplo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listViewMain = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.panel_campos = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.deny = new System.Windows.Forms.RadioButton();
            this.revoke = new System.Windows.Forms.RadioButton();
            this.grant = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.textBoxPass = new System.Windows.Forms.TextBox();
            this.textBoxUser = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.listar_usuarios = new System.Windows.Forms.Button();
            this.tabelas_do_banco_selecionado = new System.Windows.Forms.Button();
            this.bancos_existentes = new System.Windows.Forms.Button();
            this.editar_usuario = new System.Windows.Forms.Button();
            this.criar_usuario = new System.Windows.Forms.Button();
            this.textBoxId = new System.Windows.Forms.TextBox();
            this.textBoxNome = new System.Windows.Forms.TextBox();
            this.listViewTabelas = new System.Windows.Forms.ListView();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.panel_campos.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // listViewMain
            // 
            this.listViewMain.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.listViewMain.Location = new System.Drawing.Point(14, 16);
            this.listViewMain.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listViewMain.Name = "listViewMain";
            this.listViewMain.Size = new System.Drawing.Size(429, 193);
            this.listViewMain.TabIndex = 1;
            this.listViewMain.UseCompatibleStateImageBehavior = false;
            this.listViewMain.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "idBanco";
            this.columnHeader1.Width = 90;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Nome";
            this.columnHeader2.Width = 100;
            // 
            // panel_campos
            // 
            this.panel_campos.Controls.Add(this.groupBox1);
            this.panel_campos.Controls.Add(this.label4);
            this.panel_campos.Controls.Add(this.btnSalvar);
            this.panel_campos.Controls.Add(this.textBoxPass);
            this.panel_campos.Controls.Add(this.textBoxUser);
            this.panel_campos.Controls.Add(this.label2);
            this.panel_campos.Controls.Add(this.label1);
            this.panel_campos.Enabled = false;
            this.panel_campos.Location = new System.Drawing.Point(14, 259);
            this.panel_campos.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel_campos.Name = "panel_campos";
            this.panel_campos.Size = new System.Drawing.Size(430, 205);
            this.panel_campos.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.deny);
            this.groupBox1.Controls.Add(this.revoke);
            this.groupBox1.Controls.Add(this.grant);
            this.groupBox1.Location = new System.Drawing.Point(285, 16);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(129, 175);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Permissão";
            // 
            // deny
            // 
            this.deny.AutoSize = true;
            this.deny.Location = new System.Drawing.Point(17, 83);
            this.deny.Name = "deny";
            this.deny.Size = new System.Drawing.Size(64, 24);
            this.deny.TabIndex = 13;
            this.deny.TabStop = true;
            this.deny.Text = "Deny";
            this.deny.UseVisualStyleBackColor = true;
            // 
            // revoke
            // 
            this.revoke.AutoSize = true;
            this.revoke.Location = new System.Drawing.Point(17, 129);
            this.revoke.Name = "revoke";
            this.revoke.Size = new System.Drawing.Size(78, 24);
            this.revoke.TabIndex = 14;
            this.revoke.TabStop = true;
            this.revoke.Text = "Revoke";
            this.revoke.UseVisualStyleBackColor = true;
            // 
            // grant
            // 
            this.grant.AutoSize = true;
            this.grant.Location = new System.Drawing.Point(17, 32);
            this.grant.Name = "grant";
            this.grant.Size = new System.Drawing.Size(66, 24);
            this.grant.TabIndex = 12;
            this.grant.TabStop = true;
            this.grant.Text = "Grant";
            this.grant.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(118, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 20);
            this.label4.TabIndex = 11;
            this.label4.Text = "Criar usuário";
            // 
            // btnSalvar
            // 
            this.btnSalvar.Location = new System.Drawing.Point(118, 145);
            this.btnSalvar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(86, 31);
            this.btnSalvar.TabIndex = 6;
            this.btnSalvar.Text = "Criar";
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.button_salvar_Click);
            // 
            // textBoxPass
            // 
            this.textBoxPass.Enabled = false;
            this.textBoxPass.Location = new System.Drawing.Point(77, 100);
            this.textBoxPass.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxPass.Name = "textBoxPass";
            this.textBoxPass.PlaceholderText = "Senha";
            this.textBoxPass.Size = new System.Drawing.Size(192, 27);
            this.textBoxPass.TabIndex = 4;
            // 
            // textBoxUser
            // 
            this.textBoxUser.Location = new System.Drawing.Point(77, 52);
            this.textBoxUser.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxUser.Name = "textBoxUser";
            this.textBoxUser.PlaceholderText = "Usuario";
            this.textBoxUser.Size = new System.Drawing.Size(192, 27);
            this.textBoxUser.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Pass";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "User";
            // 
            // listar_usuarios
            // 
            this.listar_usuarios.Location = new System.Drawing.Point(449, 116);
            this.listar_usuarios.Name = "listar_usuarios";
            this.listar_usuarios.Size = new System.Drawing.Size(226, 37);
            this.listar_usuarios.TabIndex = 9;
            this.listar_usuarios.Text = "Listar Usuários";
            this.listar_usuarios.UseVisualStyleBackColor = true;
            this.listar_usuarios.Click += new System.EventHandler(this.listar_usuarios_Click);
            // 
            // tabelas_do_banco_selecionado
            // 
            this.tabelas_do_banco_selecionado.Location = new System.Drawing.Point(449, 73);
            this.tabelas_do_banco_selecionado.Name = "tabelas_do_banco_selecionado";
            this.tabelas_do_banco_selecionado.Size = new System.Drawing.Size(226, 37);
            this.tabelas_do_banco_selecionado.TabIndex = 7;
            this.tabelas_do_banco_selecionado.Text = "Tabelas do banco Selecionado";
            this.tabelas_do_banco_selecionado.UseVisualStyleBackColor = true;
            this.tabelas_do_banco_selecionado.Click += new System.EventHandler(this.button2_Click);
            // 
            // bancos_existentes
            // 
            this.bancos_existentes.Location = new System.Drawing.Point(449, 16);
            this.bancos_existentes.Name = "bancos_existentes";
            this.bancos_existentes.Size = new System.Drawing.Size(226, 37);
            this.bancos_existentes.TabIndex = 6;
            this.bancos_existentes.Text = "Bancos Existentes";
            this.bancos_existentes.UseVisualStyleBackColor = true;
            this.bancos_existentes.Click += new System.EventHandler(this.button1_Click);
            // 
            // editar_usuario
            // 
            this.editar_usuario.Location = new System.Drawing.Point(449, 172);
            this.editar_usuario.Name = "editar_usuario";
            this.editar_usuario.Size = new System.Drawing.Size(226, 37);
            this.editar_usuario.TabIndex = 10;
            this.editar_usuario.Text = "Editar Usuário";
            this.editar_usuario.UseVisualStyleBackColor = true;
            this.editar_usuario.Click += new System.EventHandler(this.usuario_Click);
            // 
            // criar_usuario
            // 
            this.criar_usuario.Location = new System.Drawing.Point(449, 226);
            this.criar_usuario.Name = "criar_usuario";
            this.criar_usuario.Size = new System.Drawing.Size(226, 37);
            this.criar_usuario.TabIndex = 11;
            this.criar_usuario.Text = "Criar Usuário";
            this.criar_usuario.UseVisualStyleBackColor = true;
            this.criar_usuario.Click += new System.EventHandler(this.button5_Click);
            // 
            // textBoxId
            // 
            this.textBoxId.Location = new System.Drawing.Point(14, 216);
            this.textBoxId.Name = "textBoxId";
            this.textBoxId.Size = new System.Drawing.Size(125, 27);
            this.textBoxId.TabIndex = 12;
            this.textBoxId.Visible = false;
            // 
            // textBoxNome
            // 
            this.textBoxNome.Location = new System.Drawing.Point(145, 216);
            this.textBoxNome.Name = "textBoxNome";
            this.textBoxNome.Size = new System.Drawing.Size(125, 27);
            this.textBoxNome.TabIndex = 13;
            this.textBoxNome.Visible = false;
            // 
            // listViewTabelas
            // 
            this.listViewTabelas.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4});
            this.listViewTabelas.Enabled = false;
            this.listViewTabelas.Location = new System.Drawing.Point(450, 270);
            this.listViewTabelas.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listViewTabelas.Name = "listViewTabelas";
            this.listViewTabelas.Size = new System.Drawing.Size(220, 193);
            this.listViewTabelas.TabIndex = 14;
            this.listViewTabelas.UseCompatibleStateImageBehavior = false;
            this.listViewTabelas.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "idTabela";
            this.columnHeader3.Width = 90;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "NomeTabela";
            this.columnHeader4.Width = 100;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(682, 479);
            this.Controls.Add(this.listViewTabelas);
            this.Controls.Add(this.textBoxNome);
            this.Controls.Add(this.textBoxId);
            this.Controls.Add(this.criar_usuario);
            this.Controls.Add(this.editar_usuario);
            this.Controls.Add(this.listar_usuarios);
            this.Controls.Add(this.tabelas_do_banco_selecionado);
            this.Controls.Add(this.bancos_existentes);
            this.Controls.Add(this.panel_campos);
            this.Controls.Add(this.listViewMain);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_campos.ResumeLayout(false);
            this.panel_campos.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListView listViewMain;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Panel panel_campos;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.TextBox textBoxPass;
        private System.Windows.Forms.TextBox textBoxUser;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Label label4;
        private Button listar_usuarios;
        private Button tabelas_do_banco_selecionado;
        private Button bancos_existentes;
        private Button editar_usuario;
        private Button criar_usuario;
        private TextBox textBoxId;
        private TextBox textBoxNome;
        private GroupBox groupBox1;
        private RadioButton deny;
        private RadioButton revoke;
        private RadioButton grant;
        private ListView listViewTabelas;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
        private ListView listView1;
    }
}


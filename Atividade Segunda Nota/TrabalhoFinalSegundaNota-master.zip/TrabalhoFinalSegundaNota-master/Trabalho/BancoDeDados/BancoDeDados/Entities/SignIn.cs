﻿namespace BancoDeDados.Entities
{
    public class SignIn
    {
        public string User { get; set; }
        public string Pass { get; set; }
    }
}

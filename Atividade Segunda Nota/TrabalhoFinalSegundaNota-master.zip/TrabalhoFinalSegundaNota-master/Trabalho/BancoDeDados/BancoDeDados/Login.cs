﻿using System.Data.SqlClient;
using WinFormsAppBancoExemplo;

namespace BancoDeDados
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private string conexaoString;

        private void button1_Click(object sender, EventArgs e)
        {
            this.Conectar();
        }

        private void Conectar()
        {
            try
            {
                string user = textBoxUser.Text;
                string pass = textBoxPass.Text;
                conexaoString = "Data Source=(localdb)\\MSSQLLocalDB;" +
                    "Initial Catalog=aula;" +
                    "User ID=" + user + ";" +
                    "password=" + pass + ";" +
                    "language=Portuguese";
                SqlConnection conexao = new SqlConnection(conexaoString);
                conexao.Open();

                this.Visible = false;

                Form1 forms = new Form1(user, pass);
                forms.ShowDialog();

                this.Visible = true;

                //string sqlTexto = "SELECT idPaciente, nome, email FROM Paciente";
                //SqlCommand comando = new SqlCommand(sqlTexto, conexao);
                //SqlDataReader leitor = comando.ExecuteReader();

                //listView_pacientes.Items.Clear();
                //int i = 0;
                //while (leitor.Read())
                //{
                //    listView_pacientes.Items.Add(leitor["idPaciente"].ToString());
                //    listView_pacientes.Items[i].SubItems.Add(leitor["nome"].ToString());
                //    listView_pacientes.Items[i].SubItems.Add(leitor["email"].ToString());
                //    i++;
                //}
                conexao.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Problemas de Conexão com o Banco " + ex.Message, "Alerta");
            }
        }
    }
}

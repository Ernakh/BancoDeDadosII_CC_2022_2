﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WinFormsAppBancoExemplo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public string User { get; set; }
        public string Pass { get; set; }
        public string ConexaoString { get; set; }

        public Form1(string user, string pass)
        {
            User = user;
            Pass = pass;

            ConexaoString = ConexaoString2(User, Pass);

            InitializeComponent();
        }

        public string ConexaoString2(string user, string pass)
        {
            User = user;
            Pass = pass;

            string conexaoString = "Data Source=(localdb)\\MSSQLLocalDB;" +
                        "Initial Catalog=aula;" +
                        "User ID=" + User + ";" +
                        "password=" + Pass + ";" +
                        "language=Portuguese";

            return conexaoString;
        }

        public string ConexaoString2(string user, string pass, string banco)
        {
            User = user;
            Pass = pass;

            string conexaoString = "Data Source=(localdb)\\MSSQLLocalDB;" +
                        "Initial Catalog=" + banco + ";" +
                        "User ID=" + User + ";" +
                        "password=" + Pass + ";" +
                        "language=Portuguese";

            return conexaoString;
        }

        private void limparCampos()
        {
            textBoxUser.Text = "";
            textBoxPass.Text = "";
        }

        private void carregarListView()
        {
            try
            {
                SqlConnection conexao = new SqlConnection(ConexaoString);
                conexao.Open();

                string sqlTexto = "SELECT idPaciente, nome, email FROM Paciente";
                SqlCommand comando = new SqlCommand(sqlTexto, conexao);
                SqlDataReader leitor = comando.ExecuteReader();

                listViewMain.Items.Clear();
                int i = 0;
                while (leitor.Read())
                {
                    listViewMain.Items.Add(leitor["idPaciente"].ToString());
                    listViewMain.Items[i].SubItems.Add(leitor["nome"].ToString());
                    listViewMain.Items[i].SubItems.Add(leitor["email"].ToString());
                    i++;
                }
                conexao.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Problemas de Conexão com o Banco " + ex.Message, "Alerta");
            }
        }
        private void button_conectar_Click(object sender, EventArgs e)
        {
            this.carregarListView();
        }

        private void button_cadastrar_Click(object sender, EventArgs e)
        {
            panel_campos.Enabled = true;
        }

        private void button_salvar_Click(object sender, EventArgs e)
        {
            var nome = textBoxUser.Text;
            //var pass = textBoxPass.Text;
            string permissao = "";

            if (grant.Checked)
            {
                permissao = "grant";
            }
            else if (revoke.Checked)
            {
                permissao = "revoke";
            }
            else if (deny.Checked)
            {
                permissao = "deny";
            }

            try
            {
                SqlConnection conexao = new SqlConnection(ConexaoString);
                conexao.Open();

                string sqlTexto = permissao + " select on tb_clients to " + nome + " " +
                     permissao + " select on tb_products to " + nome + " " +
                     permissao + " select on tb_providers to " + nome;
                SqlCommand comando = new SqlCommand(sqlTexto, conexao);
                SqlDataReader leitor = comando.ExecuteReader();

                conexao.Close();

                panel_campos.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Problemas de Conexão com o Banco " + ex.Message, "Alerta");
            }
        }

        private void button_deletar_Click(object sender, EventArgs e)
        {
            SqlConnection conexao = new SqlConnection(ConexaoString);
            conexao.Open();
            try
            {
                //MessageBox.Show(listView_medidasGlicemias.SelectedItems[0].Text);
                int idPaciente = int.Parse(listViewMain.SelectedItems[0].Text);

                //gerar sentenças SQL
                string sqlTexto = "DELETE FROM Paciente WHERE idPaciente = @idPaciente";

                SqlCommand comando = new SqlCommand(sqlTexto, conexao);
                comando.Parameters.AddWithValue("@idPaciente", idPaciente);

                //executar sentença SQL
                comando.ExecuteNonQuery();
                conexao.Close();
                this.limparCampos();
                //recarregar ListView
                this.carregarListView();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Problemas de Conexão com o Banco " + ex.Message, "Alerta");
            }
        }

        private void button_editar_Click(object sender, EventArgs e)
        {
            try
            {
                //panel_campos.Enabled = true;
                //textBox_idPaciente.Text = listView_pacientes.SelectedItems[0].Text;
                //textBox_nome.Text = listView_pacientes.SelectedItems[0].SubItems[1].Text;
                //textBox_email.Text = listView_pacientes.SelectedItems[0].SubItems[2].Text; ;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Primeiro conecte ao banco" + ex.Message, "Alerta");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel_campos.Enabled = false;
            listViewMain.Enabled = true;

            tabelas_do_banco_selecionado.Enabled = true;
            listar_usuarios.Enabled = true;
            editar_usuario.Enabled = false;
            criar_usuario.Enabled = false;

            //SELECIONAR OS BANCOS EXISTENTES
            try
            {
                SqlConnection conexao = new SqlConnection(ConexaoString);
                conexao.Open();

                string sqlTexto = "SELECT * FROM sys.databases";
                SqlCommand comando = new SqlCommand(sqlTexto, conexao);
                SqlDataReader leitor = comando.ExecuteReader();

                listViewMain.Items.Clear();
                int i = 0;
                while (leitor.Read())
                {
                    ListViewItem item = new ListViewItem();

                    item.Text = leitor["database_id"].ToString();
                    item.SubItems.Add(leitor["name"].ToString());
                    listViewMain.Items.Add(item);

                    i++;
                }
                conexao.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Problemas de Conexão com o Banco " + ex.Message, "Alerta");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                textBoxId.Text = listViewMain.SelectedItems[0].Text;
                textBoxNome.Text = listViewMain.SelectedItems[0].SubItems[1].Text;
                listViewMain.Enabled = false;

                tabelas_do_banco_selecionado.Enabled = false;
                listar_usuarios.Enabled = false;
                editar_usuario.Enabled = false;
                criar_usuario.Enabled = true;

                try
                {
                    SqlConnection conexao = new SqlConnection(ConexaoString2(User, Pass, textBoxNome.Text));
                    conexao.Open();

                    string sqlTexto = "SELECT * FROM information_schema.tables";
                    SqlCommand comando = new SqlCommand(sqlTexto, conexao);
                    SqlDataReader leitor = comando.ExecuteReader();

                    listViewTabelas.Items.Clear();
                    int i = 0;
                    while (leitor.Read())
                    {
                        ListViewItem item = new ListViewItem();

                        item.Text = (i + 1).ToString();
                        item.SubItems.Add(leitor["table_name"].ToString());
                        listViewTabelas.Items.Add(item);
                        i++;
                    }
                    conexao.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Problemas de Conexão com o Banco " + ex.Message, "Alerta");
                }
            }
            catch
            {
                throw new Exception();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            panel_campos.Enabled = true;
            btnSalvar.Text = "Criar";
            textBoxPass.Enabled = true;

        }

        private void usuario_Click(object sender, EventArgs e)
        {
            panel_campos.Enabled = true;
            textBoxId.Text = listViewMain.SelectedItems[0].Text;
            textBoxNome.Text = listViewMain.SelectedItems[0].SubItems[1].Text;
            textBoxUser.Text = listViewMain.SelectedItems[0].SubItems[1].Text;

            //Atribuir permissão
            PegarPermissao();

            btnSalvar.Text = "Salvar";


            //textBoxPass = "";
        }
        public void PegarPermissao()
        {
            try
            {
                textBoxId.Text = listViewMain.SelectedItems[0].Text;
                textBoxNome.Text = listViewMain.SelectedItems[0].SubItems[1].Text;
                listViewMain.Items.Clear();
                try
                {
                    SqlConnection conexao = new SqlConnection(ConexaoString2(User, Pass));
                    conexao.Open();

                    string sqlTexto = "SELECT state_desc, prmsn.permission_name as [Permission], " +
                        "sp.type_desc, sp.name, grantor_principal.name AS [Grantor], " +
                        "grantee_principal.name as [Grantee] FROM sys.all_objects AS sp " +
                        "INNER JOIN sys.database_permissions AS prmsn ON " +
                        "prmsn.major_id = sp.object_id AND prmsn.minor_id=0 " +
                        "AND prmsn.class = 1 INNER JOIN sys.database_principals AS grantor_principal " +
                        "ON grantor_principal.principal_id = prmsn.grantor_principal_id " +
                        "INNER JOIN sys.database_principals AS grantee_principal " +
                        "ON grantee_principal.principal_id = prmsn.grantee_principal_id " +
                        "WHERE grantee_principal.name = '" + textBoxNome.Text + "'";
                    SqlCommand comando = new SqlCommand(sqlTexto, conexao);
                    SqlDataReader leitor = comando.ExecuteReader();

                    //listViewMain.Items.Clear();

                    string permissao = "";

                    if (leitor.Read() != null)
                    {
                        permissao = leitor["state_desc"].ToString();
                    }

                    if (permissao == "GRANT")
                    {
                        grant.Checked = true;
                    }
                    if (permissao.ToString() == "DENY")
                    {
                        deny.Checked = true;

                    }
                    if (permissao.ToString() == "REVOKE")
                    {
                        revoke.Checked = true;

                    }

                    leitor.Close();
                    conexao.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Problemas de Conexão com o Banco " + ex.Message, "Alerta");
                }
            }
            catch
            {
                throw new Exception();
            }
        }

        private void listar_usuarios_Click(object sender, EventArgs e)
        {

            tabelas_do_banco_selecionado.Enabled = false;
            listar_usuarios.Enabled = false;
            editar_usuario.Enabled = true;
            criar_usuario.Enabled = false;

            try
            {
                textBoxId.Text = listViewMain.SelectedItems[0].Text;
                textBoxNome.Text = listViewMain.SelectedItems[0].SubItems[1].Text;
                listViewMain.Items.Clear();
                try
                {
                    SqlConnection conexao = new SqlConnection(ConexaoString2(User, Pass, textBoxNome.Text));
                    conexao.Open();

                    string sqlTexto = "SELECT * from sys.sql_logins";
                    SqlCommand comando = new SqlCommand(sqlTexto, conexao);
                    SqlDataReader leitor = comando.ExecuteReader();

                    listViewMain.Items.Clear();
                    int i = 0;
                    while (leitor.Read())
                    {
                        ListViewItem item = new ListViewItem();

                        item.Text = leitor["principal_id"].ToString();
                        item.SubItems.Add(leitor["name"].ToString());
                        listViewMain.Items.Add(item);
                        i++;
                    }
                    conexao.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Problemas de Conexão com o Banco " + ex.Message, "Alerta");
                }
            }
            catch
            {
                throw new Exception();
            }
        }
    }
}

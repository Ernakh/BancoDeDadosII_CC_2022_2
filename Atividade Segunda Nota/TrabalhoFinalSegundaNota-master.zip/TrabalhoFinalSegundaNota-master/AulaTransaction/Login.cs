﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AulaTransaction
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SignIn signIn = new SignIn();
            signIn.User = textBox1.Text;
            signIn.Password = textBox2.Text;


            if (signIn.auth(signIn))
            {
                MessageBox.Show("Login realizado com sucesso!");
            }
            else
            {
                MessageBox.Show("Error!");
            }
        }
    }
}

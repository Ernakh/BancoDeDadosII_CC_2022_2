﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AulaTransaction;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AulaTransaction
{
    internal class SignIn
    {
        public string User { get; set; }
        public string Password { get; set; }


        public bool auth(SignIn signIn)
        {
            Banco bd = new Banco(signIn);

            SqlConnection conect = bd.abrirConexao();

            try
            {
                conect.Open();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                if(conect.State == ConnectionState.Open) conect.Close();
            }
        }
    }
}
